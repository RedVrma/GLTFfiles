package com.example.samsungsecure

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
