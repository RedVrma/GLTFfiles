import 'dart:ffi';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);


  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  var databaseReference = FirebaseDatabase.instance.reference();

  var status = true;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // databaseReference.child("Users").child("User1").child("status").set(false);

    return Scaffold(
      body: Column(
        children: [
          SizedBox(
            height: 600,
            child: Container(
              decoration: const BoxDecoration(
                  color: Colors.blueAccent,
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(20),
                      bottomRight: Radius.circular(20))),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Lottie.asset('assets/securefinal.json',
                      repeat: true, animate: true),
                  Text(
                    "Your Phone is Secure!",
                    style: TextStyle(
                      fontSize: 30,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 10,),
                  Text(
                    "Threats Detected : 0",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white,
                      fontWeight: FontWeight.w200
                    ),
                  ),
                  SizedBox(height: 20,),
                  ElevatedButton(onPressed: (){}, child: Text("Report!")),
                  SizedBox(height:10),
                ],
              ),
            ),
          ),
          RealTimeScanner(status)
        ],
      ),
    );
  }
}

class RealTimeScanner extends StatelessWidget {
  var status;

  RealTimeScanner(this.status, {Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {

    return Column(
      children: [
        SizedBox(height: 20,),
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(width: 20,),
            Text("Realtime Scanner Enabled",
            style: TextStyle(
              fontSize: 20, fontWeight: FontWeight.w200,
            ),),
            Lottie.asset('assets/dotradarloading.json',)
          ],
        ),
        SizedBox(height: 20,),
        Aboutus()
      ],
    );
  }
}

class Aboutus extends StatelessWidget {
  const Aboutus({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      onPressed: () => {
        showModalBottomSheet(context: context, builder: (context){
          return Padding(
            padding: EdgeInsets.all(20),
            child: Column(
              children: [
                Image.asset('assets/ssk.png',scale: 10,),
                SizedBox(height: 20,),
                Text("Samsung Knox is a business platform for configuring and managing mobile devices – offering efficient and customized use in various industries."
                ,style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w200
                  ),),
                SizedBox(height:20),
                Row(
                  children: [
                    SizedBox(
                        child: Image.asset('assets/knoxs.png',scale: 4,),
                      height: 100,
                      width: 100,
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Knox Security Platform",style: TextStyle(fontWeight: FontWeight.bold),),
                          Text("Secured by Knox symbolizes the defense-grade security built into Samsung devices. Knox protects businesses and end users at both hardware and software level.",
                            style: TextStyle(fontWeight: FontWeight.w200),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                SizedBox(height:20),
                Row(
                  children: [
                    SizedBox(child: Image.asset('assets/knoxcloud.png',scale: 4,),
                    height: 100,
                    width: 100,),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Knox Cloud Solutions",style: TextStyle(fontWeight: FontWeight.bold),),
                          Text("Our portfolio of Knox cloud solutions allows businesses to configure, customize, deploy, analyze, and manage their devices.",
                            style: TextStyle(fontWeight: FontWeight.w200),
                          ),
                        ],
                      ),
                    )
                  ],
                ),

              ],
            ),
          );
        },shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20)
        ))
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(
            height: 15,
          ),
          Row(
            children: [
              const Icon(
                Icons.info_outline_rounded,
                size: 20,
                color: Colors.blueAccent,
              ),
              const SizedBox(width: 19),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "About Us",
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                    SizedBox(
                      height: 4,
                    ),
                    Text(
                      "Get to know us and our mission to protect you with advanced technology.",
                      style: Theme.of(context).textTheme.bodySmall!.copyWith(
                          color: Colors.grey
                      ),
                    ),
                  ],
                ),
              ),
              const Spacer(),
              IconButton(
                icon: Icon(
                  Icons.arrow_forward_ios,
                  color: Theme.of(context).colorScheme.onSurface,
                  size: 16,
                ),
                onPressed: () {},
              ),
            ],
          ),
          const SizedBox(
            height: 15,
          ),
          Divider(
            height: 1,
            color: Colors.black12,
          ),
        ],
      ),
    );
  }
}


